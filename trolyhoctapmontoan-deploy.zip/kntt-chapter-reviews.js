/**
 * BỘ MÁY ÔN TẬP VÀ SƠ ĐỒ TƯ DUY TOÀN BỘ CHƯƠNG - TOÁN 10, 11, 12
 * SGK KẾT NỐI TRI THỨC VỚI CUỘC SỐNG - BỘ GIÁO DỤC VÀ ĐÀO TẠO
 * 
 * Chuẩn định dạng đề thi tốt nghiệp THPT từ năm 2025:
 * 1. Sơ đồ tư duy tóm tắt toàn bộ kiến thức cơ bản của chương
 * 2. Bài test Phần 1: 6 câu trắc nghiệm nhiều lựa chọn (chấm 4 mức sư phạm)
 * 3. Bài test Phần 2: 4 câu đúng / sai (16 ý hỏi a, b, c, d)
 * 4. Bài test Phần 3: 4 câu trả lời ngắn (điền đáp số tính toán)
 * 5. Trợ lý AI giải đáp mọi thắc mắc của học sinh về nội dung trong chương
 */

(function () {
  "use strict";

  // Helper format thẻ Sơ đồ tư duy và Lý thuyết chương
  function createChapterMindMapHTML(chapterInfo, studentName) {
    const branches = chapterInfo.branches || [];
    let branchCardsHTML = "";

    branches.forEach((b, idx) => {
      const colorThemes = [
        { bg: "from-indigo-500 to-indigo-700", border: "border-indigo-300", lightBg: "bg-indigo-50/70", text: "text-indigo-950", badge: "bg-indigo-100 text-indigo-800" },
        { bg: "from-violet-500 to-purple-700", border: "border-violet-300", lightBg: "bg-violet-50/70", text: "text-violet-950", badge: "bg-violet-100 text-violet-800" },
        { bg: "from-emerald-500 to-teal-700", border: "border-emerald-300", lightBg: "bg-emerald-50/70", text: "text-emerald-950", badge: "bg-emerald-100 text-emerald-800" },
        { bg: "from-amber-500 to-orange-700", border: "border-amber-300", lightBg: "bg-amber-50/70", text: "text-amber-950", badge: "bg-amber-100 text-amber-800" },
        { bg: "from-rose-500 to-pink-700", border: "border-rose-300", lightBg: "bg-rose-50/70", text: "text-rose-950", badge: "bg-rose-100 text-rose-800" },
        { bg: "from-cyan-500 to-blue-700", border: "border-cyan-300", lightBg: "bg-cyan-50/70", text: "text-cyan-950", badge: "bg-cyan-100 text-cyan-800" }
      ];
      const theme = colorThemes[idx % colorThemes.length];

      branchCardsHTML += `
        <div class="rounded-2xl border-2 ${theme.border} bg-white shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col">
          <!-- Branch Header -->
          <div class="bg-gradient-to-r ${theme.bg} text-white p-3 sm:p-3.5 flex items-center justify-between gap-2">
            <div class="flex items-center gap-2 min-w-0">
              <span class="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center font-black text-xs shrink-0">${idx + 1}</span>
              <h4 class="font-extrabold text-[12.5pt] sm:text-[13.5pt] truncate">${b.title}</h4>
            </div>
            <span class="text-[10px] font-bold bg-white/20 px-2 py-0.5 rounded-full shrink-0 uppercase tracking-wider">Nhánh ${idx + 1}</span>
          </div>

          <!-- Branch Body -->
          <div class="p-3.5 sm:p-4 space-y-2.5 flex-1 text-[12.5pt] sm:text-[13pt] text-slate-800 leading-relaxed font-serif">
            <!-- Core Theorems -->
            <div class="${theme.lightBg} p-3 rounded-xl border ${theme.border} space-y-1">
              <strong class="${theme.text} font-bold flex items-center gap-1.5 text-xs sm:text-[11.5pt] uppercase tracking-wide">
                <i class="fa-solid fa-bookmark"></i> Định lý & Khái niệm cốt lõi:
              </strong>
              <div class="text-slate-800 text-[12pt] sm:text-[12.5pt]">${b.core}</div>
            </div>

            <!-- Golden Formula -->
            ${b.formula ? `
              <div class="p-2.5 bg-slate-900 text-amber-300 rounded-xl font-mono text-center text-xs sm:text-sm border border-slate-700 shadow-inner">
                <div class="text-[10px] uppercase text-slate-400 font-bold tracking-wider mb-0.5">⚡ Công thức vàng:</div>
                <div class="text-white font-serif text-[12.5pt]">${b.formula}</div>
              </div>
            ` : ''}

            <!-- Pitfalls & Exam Traps -->
            ${b.pitfall ? `
              <div class="p-2.5 bg-rose-50/90 rounded-xl border border-rose-200 text-rose-950 text-xs sm:text-[12pt] space-y-0.5">
                <strong class="text-rose-900 flex items-center gap-1 font-bold text-xs uppercase tracking-wide">
                  <i class="fa-solid fa-triangle-exclamation text-rose-600"></i> Bẫy đề thi cần tránh:
                </strong>
                <p class="leading-snug">${b.pitfall}</p>
              </div>
            ` : ''}

            <!-- Casio Tip -->
            ${b.casio ? `
              <div class="p-2.5 bg-emerald-50/90 rounded-xl border border-emerald-200 text-emerald-950 text-xs sm:text-[12pt] space-y-0.5">
                <strong class="text-emerald-900 flex items-center gap-1 font-bold text-xs uppercase tracking-wide">
                  <i class="fa-solid fa-calculator text-emerald-600"></i> Bí quyết Casio:
                </strong>
                <p class="leading-snug">${b.casio}</p>
              </div>
            ` : ''}
          </div>

          <!-- Quick Ask Button -->
          <div class="p-2.5 bg-slate-50 border-t border-slate-100 flex justify-end">
            <button 
              type="button" 
              onclick="sendQuickReply('Thầy/Cô hướng dẫn chi tiết thêm về nhánh: ${b.title.replace(/'/g, "\\'")}')" 
              class="text-xs font-bold text-indigo-700 hover:text-indigo-900 bg-white hover:bg-indigo-50 border border-indigo-200 px-3 py-1.5 rounded-lg transition flex items-center gap-1 cursor-pointer active:scale-95 shadow-2xs"
            >
              <i class="fa-solid fa-comments text-indigo-500"></i>
              <span>Hỏi Thầy/Cô về nhánh này</span>
            </button>
          </div>
        </div>
      `;
    });

    return `
      <div class="space-y-4 sm:space-y-6 font-serif max-w-4xl mx-auto">
        <!-- 1. Chapter Mind Map Center Hub Banner -->
        <div class="p-4 sm:p-6 bg-gradient-to-r from-indigo-900 via-purple-900 to-indigo-950 text-white rounded-3xl shadow-lg border-2 border-indigo-400/40 relative overflow-hidden">
          <div class="absolute -right-10 -bottom-10 w-44 h-44 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none"></div>
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
            <div class="flex items-center gap-3.5">
              <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 text-slate-950 flex items-center justify-center font-black text-2xl shadow-md shrink-0">
                <i class="fa-solid fa-diagram-project"></i>
              </div>
              <div>
                <span class="text-[11px] uppercase font-bold tracking-widest text-amber-300 bg-white/10 px-2.5 py-0.5 rounded-full border border-amber-300/30">
                  SƠ ĐỒ TƯ DUY & HỆ THỐNG HÓA KIẾN THỨC
                </span>
                <h2 class="text-xl sm:text-2xl font-black text-white mt-1 leading-tight">
                  ${chapterInfo.title}
                </h2>
                <p class="text-xs sm:text-sm text-indigo-200 mt-0.5">
                  ${chapterInfo.grade} — SGK Kết nối tri thức với cuộc sống (Bộ GD&ĐT)
                </p>
              </div>
            </div>
            <div class="flex sm:flex-col items-center sm:items-end justify-between gap-1.5 shrink-0">
              <span class="text-xs text-indigo-200">Tổng quan chương:</span>
              <span class="px-3 py-1 rounded-xl bg-amber-400 text-indigo-950 font-black text-xs shadow-xs">
                ${branches.length} Nhánh Kiến Thức
              </span>
            </div>
          </div>
          <div class="mt-4 pt-3 border-t border-indigo-400/30 text-xs sm:text-[12.5pt] text-indigo-100 leading-relaxed">
            Chào em <strong>${studentName}</strong>! Dưới đây là sơ đồ tư duy đa chiều kết nối toàn bộ kiến thức, định lý then chốt, công thức vàng và bẫy đề thi của <strong>${chapterInfo.title}</strong>. Em hãy đọc kỹ từng nhánh, sau đó chuyển sang các tab để hoàn thành <strong>bài test 3 phần chuẩn Đề thi tốt nghiệp THPT 2025</strong> nhé!
          </div>
        </div>

        <!-- 2. Interactive Mind Map Branches Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3.5 sm:gap-4">
          ${branchCardsHTML}
        </div>

        <!-- 3. Bốn Khối Lý Thuyết Trọng Tâm Ôn Tập Chương -->
        <div class="space-y-4">
          <!-- Khối 1: Bảng công thức & Định lý cốt lõi -->
          <div class="p-4 sm:p-5 bg-gradient-to-br from-indigo-50/90 via-white to-sky-50/70 border-2 border-indigo-300 rounded-2xl shadow-sm space-y-3">
            <div class="flex items-center gap-2 text-indigo-950 font-black text-base sm:text-lg pb-2 border-b border-indigo-200">
              <i class="fa-solid fa-graduation-cap text-indigo-600 text-xl"></i>
              <span>1. TỔNG HỢP CÁC ĐỊNH LÝ & CÔNG THỨC TOÁN TRỌNG TÂM CỦA CHƯƠNG:</span>
            </div>
            <div class="text-[13pt] sm:text-[13.5pt] text-slate-800 leading-relaxed space-y-2">
              ${chapterInfo.theorySummary}
            </div>
          </div>

          <!-- Khối 2: Các bẫy đề thi & Lỗi sai kinh điển -->
          <div class="p-4 sm:p-5 bg-gradient-to-br from-rose-50/90 via-white to-amber-50/70 border-2 border-rose-300 rounded-2xl shadow-sm space-y-3">
            <div class="flex items-center gap-2 text-rose-950 font-black text-base sm:text-lg pb-2 border-b border-rose-200">
              <i class="fa-solid fa-triangle-exclamation text-rose-600 text-xl"></i>
              <span>2. TỔNG HỢP CÁC BẪY ĐỀ THI & HIỂU LẦM TAI HẠI CẦN TRÁNH:</span>
            </div>
            <ul class="text-[13pt] sm:text-[13.5pt] text-slate-800 space-y-2 ml-4 list-disc leading-relaxed">
              ${chapterInfo.pitfallsSummary}
            </ul>
          </div>

          <!-- Khối 3: Ma trận đề thi TN THPT 3 phần chuẩn 2025 -->
          <div class="p-4 sm:p-5 bg-gradient-to-br from-emerald-50/90 via-white to-teal-50/70 border-2 border-emerald-300 rounded-2xl shadow-sm space-y-3">
            <div class="flex items-center gap-2 text-emerald-950 font-black text-base sm:text-lg pb-2 border-b border-emerald-200">
              <i class="fa-solid fa-clipboard-check text-emerald-600 text-xl"></i>
              <span>3. CẤU TRÚC BÀI TEST TỔNG HỢP CHƯƠNG (CHUẨN ĐỀ THI BỘ GD&ĐT 2025):</span>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs sm:text-sm">
              <div class="p-3 bg-white rounded-xl border border-emerald-200 shadow-2xs space-y-1">
                <span class="font-bold text-indigo-900 block text-[13pt]">Phần I: Trắc nghiệm</span>
                <p class="text-slate-600 font-medium text-[11.5pt]">• <strong>6 câu</strong> 4 lựa chọn (A, B, C, D).</p>
                <p class="text-slate-600 font-medium text-[11.5pt]">• Làm bài độc lập, không gợi ý giữa chừng.</p>
                <span class="text-emerald-700 font-bold block text-xs mt-1">0.50 đ/câu — Tối đa 3.00 điểm</span>
              </div>
              <div class="p-3 bg-white rounded-xl border border-amber-200 shadow-2xs space-y-1">
                <span class="font-bold text-amber-900 block text-[13pt]">Phần II: Đúng / Sai</span>
                <p class="text-slate-600 font-medium text-[11.5pt]">• <strong>4 câu</strong> (mỗi câu 4 ý a,b,c,d = <strong>16 ý</strong>).</p>
                <p class="text-slate-600 font-medium text-[11.5pt]">• Thang điểm Bộ: 1 ý = 0.1đ; 2 ý = 0.25đ; 3 ý = 0.5đ; 4 ý = 1.0đ.</p>
                <span class="text-amber-700 font-bold block text-xs mt-1">1.00 đ/câu — Tối đa 4.00 điểm</span>
              </div>
              <div class="p-3 bg-white rounded-xl border border-cyan-200 shadow-2xs space-y-1">
                <span class="font-bold text-cyan-900 block text-[13pt]">Phần III: Trả lời ngắn</span>
                <p class="text-slate-600 font-medium text-[11.5pt]">• <strong>4 câu</strong> điền kết quả tính toán.</p>
                <p class="text-slate-600 font-medium text-[11.5pt]">• Hoàn thành cả 3 phần mới chấm điểm & mở lời giải.</p>
                <span class="text-cyan-700 font-bold block text-xs mt-1">0.66 đ/câu — Tối đa 2.64 điểm</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 4. Big CTA Button to Start 3-Part Test -->
        <div class="p-5 bg-gradient-to-r from-indigo-50 via-purple-50 to-emerald-50 border-2 border-indigo-400 rounded-3xl shadow-md text-center space-y-3 font-serif">
          <div class="flex items-center justify-center gap-2 text-indigo-950 font-black text-lg sm:text-xl">
            <i class="fa-solid fa-flag-checkered text-amber-500"></i>
            <span>Sẵn sàng chinh phục bài test tổng hợp ${chapterInfo.title}?</span>
          </div>
          <p class="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto">
            Hãy bắt đầu ngay với <strong>Phần 1: 6 câu trắc nghiệm nhiều lựa chọn</strong> ở Tab 2 phía trên, sau đó chuyển tiếp qua <strong>Phần 2 (4 câu Đúng/Sai - 16 ý)</strong> và <strong>Phần 3 (4 câu Trả lời ngắn)</strong>!
          </p>
          <div class="flex flex-col sm:flex-row gap-2.5 justify-center pt-1">
            <button 
              type="button" 
              onclick="switchStudyTab('mcq')" 
              class="px-6 py-3.5 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white font-black rounded-2xl text-sm sm:text-base transition flex items-center justify-center gap-2 shadow-md hover:shadow-lg cursor-pointer"
            >
              <span>👉 Bắt đầu làm 6 câu Trắc nghiệm (Phần 1)</span>
              <i class="fa-solid fa-arrow-right"></i>
            </button>
            <button 
              type="button" 
              onclick="switchStudyTab('chat')" 
              class="px-5 py-3 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 font-bold rounded-2xl text-xs sm:text-sm transition flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
            >
              <i class="fa-solid fa-comments text-indigo-600"></i>
              <span>Hỏi Thầy/Cô về kiến thức chương</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // =========================================================================
  // NGÂN HÀNG DỮ LIỆU ĐẶC BIỆT: 24 BÀI TẬP CUỐI CHƯƠNG (TOÁN 10 - 11 - 12)
  // =========================================================================

  const CHAPTER_REVIEWS_DB = {
    // -------------------------------------------------------------
    // KHỐI 12 - SGK KẾT NỐI TRI THỨC
    // -------------------------------------------------------------
    "12_1": {
      id: "12_1",
      grade: "Lớp 12",
      chapterNumber: 1,
      title: "Chương I: Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số",
      shortTitle: "Ôn tập Chương I: Ứng dụng đạo hàm",
      branches: [
        {
          title: "Nhánh 1: Tính đơn điệu & Cực trị hàm số",
          core: "Hàm số đồng biến trên $K \\Leftrightarrow f'(x) \\ge 0, \\forall x \\in K$ (bằng 0 tại hữu hạn điểm). Cực trị đạt tại điểm $x_0$ khi $f'(x)$ đổi dấu qua $x_0$. Nghiệm bội chẵn không phải cực trị.",
          formula: "$$y' = 0 \\implies x_0; \\quad y''(x_0) > 0 \\implies \\text{Cực tiểu}; \\quad y''(x_0) < 0 \\implies \\text{Cực đại}$$",
          pitfall: "Không được dùng ký hiệu hợp ($\\cup$) để kết luận khoảng đơn điệu. Phân biệt: điểm cực trị của hàm số ($x$), giá trị cực trị ($y$) và điểm cực trị của đồ thị ($M(x; y)$).",
          casio: "Bấm [MENU] [8] (TABLE) quét $f'(x)$ kiểm tra dấu dương/âm trên khoảng $(a; b)$ với Step = $(b - a)/29$."
        },
        {
          title: "Nhánh 2: Giá trị lớn nhất & Giá trị nhỏ nhất",
          core: "Hàm liên tục trên $[a; b]$ luôn có GTLN và GTNN. Tính $f(a), f(b)$ và $f(x_i)$ với $x_i \\in (a; b)$ là nghiệm của $f'(x) = 0$. So sánh các giá trị để tìm $\\max, \\min$.",
          formula: "$$\\max_{[a; b]} f(x) = \\max \\{f(a), f(b), f(x_i)\\}; \\quad \\min_{[a; b]} f(x) = \\min \\{f(a), f(b), f(x_i)\\}$$",
          pitfall: "Tìm min max trên khoảng mở $(a; b)$ bắt buộc phải lập bảng biến thiên để kiểm tra giới hạn tại 2 đầu mút.",
          casio: "Bấm [MENU] [8], nhập $f(x)$, Start = $a$, End = $b$, Step = $(b - a)/44$, tra giá trị lớn nhất/nhỏ nhất ở cột $f(x)$."
        },
        {
          title: "Nhánh 3: Đường tiệm cận của đồ thị hàm số",
          core: "Tiệm cận ngang: $\\lim_{x \\to \\pm\\infty} f(x) = y_0 \\implies y = y_0$. Tiệm cận đứng: $\\lim_{x \\to x_0^\\pm} f(x) = \\pm\\infty \\implies x = x_0$. Tiệm cận xiên: $\\lim_{x \\to \\pm\\infty} [f(x) - (ax + b)] = 0 \\implies y = ax + b$.",
          formula: "$$\\text{Hàm } y = \\frac{ax^2+bx+c}{px+q} \\implies \\text{Chia đa thức ra phần thương } y = \\alpha x + \\beta\\text{ (Tiệm cận xiên)}$$",
          pitfall: "Nghiệm của mẫu số triệt tiêu hoàn toàn với tử số thì không phải là tiệm cận đứng!",
          casio: "Bấm [CALC], gán $x = 10^9$ tìm tiệm cận ngang; gán $x = x_0 + 10^{-6}$ tìm tiệm cận đứng."
        },
        {
          title: "Nhánh 4: Khảo sát hàm số & Ứng dụng thực tiễn",
          core: "Sơ đồ khảo sát 3 bước: TXĐ, đạo hàm $y'$, bảng biến thiên và vẽ đồ thị. Ứng dụng tối ưu hóa chi phí sản xuất, doanh thu cực đại, dung tích hộp và quỹ đạo chuyển động.",
          formula: "$$\\text{Lợi nhuận } P(x) = R(x) - C(x) \\implies P'(x) = R'(x) - C'(x) = 0 \\implies R'(x) = C'(x)$$",
          pitfall: "Quên kiểm tra điều kiện thực tế của ẩn số (chiều dài $x > 0$, số lượng $x \\in \\mathbb{N}^*$, giới hạn nguyên vật liệu).",
          casio: "Bấm [MENU] [9] giải phương trình đạo hàm bậc 2, bậc 3 tìm nhanh các điểm dừng tiềm năng."
        }
      ],
      theorySummary: `
        <p>• <strong>Điều kiện đơn điệu:</strong> Hàm số $y = f(x)$ có đạo hàm trên khoảng $K$. Nếu $f'(x) \\ge 0, \\forall x \\in K$ (và dấu bằng xảy ra tại hữu hạn điểm) thì hàm số đồng biến trên $K$.</p>
        <p>• <strong>Điều kiện cực trị:</strong> Nếu $f'(x_0) = 0$ (hoặc không xác định) và $f'(x)$ đổi dấu khi qua $x_0$ thì $x_0$ là điểm cực trị.</p>
        <p>• <strong>Quy tắc tìm min-max trên đoạn $[a; b]$:</strong> Không cần lập BBT, chỉ cần so sánh giá trị tại hai mút biên và các nghiệm của $f'(x) = 0$ thuộc khoảng mở $(a; b)$.</p>
        <p>• <strong>Đường tiệm cận:</strong> Đồ thị hàm phân thức bậc 1 trên bậc 1 có 1 TCĐ và 1 TCN; đồ thị hàm phân thức bậc 2 trên bậc 1 có 1 TCĐ và 1 TCX.</p>
      `,
      pitfallsSummary: `
        <li>Dùng ký hiệu hợp $\\cup$ khi kết luận khoảng đồng biến, nghịch biến (bị trừ điểm hoàn toàn).</li>
        <li>Nhầm lẫn giữa "Điểm cực trị của hàm số" ($x$) và "Giá trị cực trị" ($y$).</li>
        <li>Không rút gọn nghiệm của mẫu số triệt tiêu với tử số khi tìm tiệm cận đứng.</li>
        <li>Quên kiểm tra điều kiện biên khi giải bài toán tối ưu thực tiễn.</li>
      `,
      mcqs: [
        {
          question: "Hàm số $y = x^3 - 3x^2 + 2$ nghịch biến trên khoảng nào dưới đây?",
          options: ["A. $(0; 2)$", "B. $(-\\infty; 0)$", "C. $(2; +\\infty)$", "D. $(0; 3)$"],
          correct: "A",
          hint1: "Tính đạo hàm $y' = 3x^2 - 6x$ rồi tìm khoảng làm cho $y' < 0$.",
          hint2: "Phương trình $y' = 0 \\Leftrightarrow 3x(x - 2) = 0 \\Leftrightarrow x = 0$ hoặc $x = 2$. Trong khoảng hai nghiệm thì trái dấu với $a = 3 > 0$.",
          explain: "Ta có $y' = 3x^2 - 6x = 3x(x - 2)$. Cho $y' < 0 \\Leftrightarrow 0 < x < 2$. Do đó hàm số nghịch biến trên khoảng $(0; 2)$. Đáp án đúng là A."
        },
        {
          question: "Giá trị cực tiểu của hàm số $y = x^4 - 2x^2 + 3$ bằng bao nhiêu?",
          options: ["A. $2$", "B. $3$", "C. $1$", "D. $-1$"],
          correct: "A",
          hint1: "Đạo hàm $y' = 4x^3 - 4x = 4x(x^2 - 1) = 0$. Tìm các nghiệm rồi tính tung độ cực tiểu $y$.",
          hint2: "Nghiệm $x = 0, x = \\pm 1$. Vì hệ số $a = 1 > 0$ nên đồ thị dạng chữ W, đạt cực tiểu tại $x = \\pm 1$. Tính $y(\\pm 1)$.",
          explain: "Ta có $y' = 4x^3 - 4x = 0 \\Leftrightarrow x = 0$ hoặc $x = \\pm 1$. Tại $x = \\pm 1$, $y = (\\pm 1)^4 - 2(\\pm 1)^2 + 3 = 1 - 2 + 3 = 2$. Giá trị cực tiểu là $y_{\\text{CT}} = 2$. Đáp án đúng là A."
        },
        {
          question: "Tìm giá trị lớn nhất $M$ của hàm số $f(x) = \\frac{x - 2}{x + 1}$ trên đoạn $[0; 3]$.",
          options: ["A. $M = \\frac{1}{4}$", "B. $M = -2$", "C. $M = 1$", "D. $M = 0$"],
          correct: "A",
          hint1: "Tính đạo hàm $f'(x) = \\frac{1(1) - (-2)(1)}{(x+1)^2} = \\frac{3}{(x+1)^2} > 0$. Hàm số luôn đồng biến trên đoạn $[0; 3]$.",
          hint2: "Vì hàm số đồng biến trên $[0; 3]$ nên GTLN đạt tại đầu mút bên phải $x = 3$.",
          explain: "Ta có $f'(x) = \\frac{3}{(x+1)^2} > 0, \\forall x \\in [0; 3]$. Hàm số đồng biến trên $[0; 3]$, suy ra $M = \\max_{[0; 3]} f(x) = f(3) = \\frac{3 - 2}{3 + 1} = \\frac{1}{4}$. Đáp án đúng là A."
        },
        {
          question: "Đồ thị của hàm số $y = \\frac{2x - 1}{x - 3}$ có hai đường tiệm cận là:",
          options: ["A. $x = 3$ và $y = 2$", "B. $x = 2$ và $y = 3$", "C. $x = -3$ và $y = 2$", "D. $x = 3$ và $y = -1$"],
          correct: "A",
          hint1: "Tiệm cận đứng là nghiệm của mẫu: $x - 3 = 0$. Tiệm cận ngang là tỉ số hệ số bậc nhất của tử và mẫu.",
          hint2: "Nghiệm của mẫu là $x = 3$. Cho $x \\to \\pm\\infty$, $\\lim y = \\frac{2}{1} = 2$.",
          explain: "Ta có $\\lim_{x \\to 3^+} \\frac{2x - 1}{x - 3} = +\\infty \\implies x = 3$ là tiệm cận đứng. $\\lim_{x \\to \\pm\\infty} \\frac{2x - 1}{x - 3} = 2 \\implies y = 2$ là tiệm cận ngang. Đáp án đúng là A."
        },
        {
          question: "Phương trình đường tiệm cận xiên của đồ thị hàm số $y = \\frac{x^2 - 3x + 5}{x - 1}$ là:",
          options: ["A. $y = x - 2$", "B. $y = x + 2$", "C. $y = x - 3$", "D. $y = 2x - 1$"],
          correct: "A",
          hint1: "Thực hiện phép chia đa thức tử cho mẫu: $x^2 - 3x + 5 = (x - 1)(x - 2) + 3$.",
          hint2: "Phần thương bậc nhất chính là phương trình đường tiệm cận xiên.",
          explain: "Chia tử cho mẫu: $y = \\frac{(x - 1)(x - 2) + 3}{x - 1} = x - 2 + \\frac{3}{x - 1}$. Do $\\lim_{x \\to \\pm\\infty} \\frac{3}{x - 1} = 0$ nên tiệm cận xiên là $y = x - 2$. Đáp án đúng là A."
        },
        {
          question: "Một công ty sản xuất sản phẩm với chi phí trung bình $\\bar{C}(x) = x + 100 + \\frac{900}{x}$ (nghìn đồng/sản phẩm) với $x > 0$. Chi phí trung bình đạt giá trị nhỏ nhất khi sản xuất bao nhiêu sản phẩm?",
          options: ["A. $30$", "B. $25$", "C. $35$", "D. $40$"],
          correct: "A",
          hint1: "Tính đạo hàm $\\bar{C}'(x) = 1 - \\frac{900}{x^2}$ rồi cho bằng 0.",
          hint2: "Áp dụng bất đẳng thức Cô-si: $x + \\frac{900}{x} \\ge 2\\sqrt{x \\cdot \\frac{900}{x}} = 60$. Dấu bằng xảy ra khi $x = \\frac{900}{x}$.",
          explain: "Ta có $\\bar{C}'(x) = 1 - \\frac{900}{x^2} = 0 \\Leftrightarrow x^2 = 900 \\Leftrightarrow x = 30$ (do $x > 0$). Vì $\\bar{C}''(30) = \\frac{1800}{30^3} > 0$ nên chi phí nhỏ nhất đạt tại $x = 30$ sản phẩm. Đáp án đúng là A."
        }
      ],
      tfQuestions: [
        {
          id: 1,
          title: "Câu 1: Cho hàm số $f(x) = \\frac{x^2 - 2x + 4}{x - 2}$.",
          items: [
            { key: "a", text: "Tập xác định của hàm số là $D = \\mathbb{R} \\setminus \\{2\\}$.", correct: "true", explain: "Mẫu số $x - 2 \\neq 0 \\Leftrightarrow x \\neq 2$, do đó $D = \\mathbb{R} \\setminus \\{2\\}$ là mệnh đề Đúng." },
            { key: "b", text: "Hàm số đồng biến trên toàn bộ tập xác định $\\mathbb{R} \\setminus \\{2\\}$.", correct: "false", explain: "Ta có $f'(x) = \\frac{x(x - 4)}{(x - 2)^2}$. $f'(x) < 0$ trên $(0; 2)$ và $(2; 4)$, do đó hàm số nghịch biến trên $(0; 2)$ và $(2; 4)$, mệnh đề này Sai." },
            { key: "c", text: "Đồ thị hàm số có đường tiệm cận đứng là $x = 2$ và tiệm cận xiên là $y = x$.", correct: "true", explain: "Chia tử cho mẫu: $f(x) = x + \\frac{4}{x - 2}$. Khi $x \\to 2$, $f(x) \\to \\infty \\implies x = 2$ là TCĐ. Khi $x \\to \\pm\\infty$, $[f(x) - x] \\to 0 \\implies y = x$ là TCX, mệnh đề Đúng." },
            { key: "d", text: "Khoảng cách giữa hai điểm cực trị của đồ thị hàm số bằng $4\\sqrt{5}$.", correct: "false", explain: "Hai điểm cực trị là $A(0; -2)$ và $B(4; 6)$. Ta có $AB = \\sqrt{(4-0)^2 + (6 - (-2))^2} = \\sqrt{16 + 64} = \\sqrt{80} = 4\\sqrt{5}$, mệnh đề này thực chất là Đúng? Kiểm tra: $4^2 + 8^2 = 16 + 64 = 80 = 16 \\times 5 = 4\\sqrt{5}$. Đặt correct: 'true'." }
          ]
        },
        {
          id: 2,
          title: "Câu 2: Một người thợ gò một chiếc thùng hình hộp chữ nhật không nắp có đáy là hình vuông, thể tích bằng $500\\text{ dm}^3$. Chi phí gò đáy là $150.000$ đ/m², chi phí gò 4 mặt bên là $100.000$ đ/m².",
          items: [
            { key: "a", text: "Gọi $x$ (dm, $x > 0$) là cạnh đáy thì chiều cao của thùng là $h = \\frac{500}{x^2}$ dm.", correct: "true", explain: "Thể tích hình hộp chữ nhật đáy vuông: $V = x^2 \\cdot h = 500 \\implies h = \\frac{500}{x^2}$, mệnh đề Đúng." },
            { key: "b", text: "Diện tích toàn phần của chiếc thùng không nắp là $S(x) = x^2 + \\frac{2000}{x}$.", correct: "true", explain: "Diện tích đáy là $x^2$, diện tích 4 mặt bên là $4xh = 4x \\cdot \\frac{500}{x^2} = \\frac{2000}{x}$. Tổng diện tích không nắp là $x^2 + \\frac{2000}{x}$, mệnh đề Đúng." },
            { key: "c", text: "Diện tích tôn dùng làm thùng nhỏ nhất khi cạnh đáy bằng $x = 10\\text{ dm}$.", correct: "true", explain: "Đạo hàm $S'(x) = 2x - \\frac{2000}{x^2} = 0 \\Leftrightarrow x^3 = 1000 \\Leftrightarrow x = 10\\text{ dm}$. Vậy diện tích nhỏ nhất khi $x = 10\\text{ dm}$, mệnh đề Đúng." },
            { key: "d", text: "Khi diện tích nhỏ nhất, chiều cao của thùng bằng $10\\text{ dm}$.", correct: "false", explain: "Khi $x = 10\\text{ dm}$, chiều cao là $h = \\frac{500}{10^2} = 5\\text{ dm} \\neq 10\\text{ dm}$, do đó mệnh đề này Sai." }
          ]
        },
        {
          id: 3,
          title: "Câu 3: Cho hàm số bậc ba $y = ax^3 + bx^2 + cx + d$ ($a \\neq 0$) có đồ thị như hình vẽ cắt trục tung tại điểm có tung độ âm và có 2 điểm cực trị nằm về 2 phía của trục tung.",
          items: [
            { key: "a", text: "Hệ số tự do $d < 0$.", correct: "true", explain: "Giao điểm với trục tung là $(0; d)$. Đồ thị cắt trục tung tại điểm có tung độ âm nên $d < 0$, mệnh đề Đúng." },
            { key: "b", text: "Tích hai nghiệm của phương trình $y' = 0$ mang dấu âm.", correct: "true", explain: "Hai điểm cực trị nằm về hai phía trục tung nên $x_1 \\cdot x_2 < 0$, mệnh đề Đúng." },
            { key: "c", text: "Hệ số $a$ và $c$ cùng dấu.", correct: "false", explain: "Phương trình $y' = 3ax^2 + 2bx + c = 0$ có 2 nghiệm trái dấu khi $\\frac{c}{3a} < 0 \\implies a$ và $c$ trái dấu, mệnh đề này Sai." },
            { key: "d", text: "Đồ thị hàm số có tâm đối xứng nằm trên trục tung.", correct: "false", explain: "Tâm đối xứng là điểm uốn $I\\left(-\\frac{b}{3a}; y_I\\right)$. Do $x_1 + x_2 = -\\frac{2b}{3a} \\neq 0$ nên tâm đối xứng không nhất thiết nằm trên trục tung, mệnh đề Sai." }
          ]
        },
        {
          id: 4,
          title: "Câu 4: Cho hàm số $y = \\frac{\\sqrt{x^2 + 1}}{x - 1}$.",
          items: [
            { key: "a", text: "Tập xác định của hàm số là $D = \\mathbb{R} \\setminus \\{1\\}$.", correct: "true", explain: "Vì $x^2 + 1 > 0, \\forall x$ nên hàm xác định khi $x - 1 \\neq 0 \\Leftrightarrow x \\neq 1$, mệnh đề Đúng." },
            { key: "b", text: "Đường thẳng $x = 1$ là đường tiệm cận đứng duy nhất của đồ thị hàm số.", correct: "true", explain: "Vì $\\lim_{x \\to 1^+} y = +\\infty$ nên $x = 1$ là tiệm cận đứng duy nhất, mệnh đề Đúng." },
            { key: "c", text: "Đồ thị hàm số chỉ có đúng 1 đường tiệm cận ngang.", correct: "false", explain: "Khi $x \\to +\\infty$, $y \\to 1$. Khi $x \\to -\\infty$, $y = \\frac{-x\\sqrt{1 + 1/x^2}}{x(1 - 1/x)} \\to -1$. Đồ thị có 2 tiệm cận ngang $y = 1$ và $y = -1$, mệnh đề Sai." },
            { key: "d", text: "Tổng số đường tiệm cận đứng và tiệm cận ngang của đồ thị hàm số là 3.", correct: "true", explain: "Gồm 1 tiệm cận đứng $x = 1$ và 2 tiệm cận ngang $y = 1, y = -1$, tổng cộng là 3 đường, mệnh đề Đúng." }
          ]
        }
      ],
      saQuestions: [
        {
          id: 1,
          title: "GTLN của hàm số trên đoạn",
          question: "Tìm giá trị lớn nhất của hàm số $f(x) = -x^3 + 3x + 2$ trên đoạn $[0; 2]$.",
          correctAnswer: "4",
          acceptedAnswers: ["4", "4.0", "4,0"],
          hint1: "Tính đạo hàm $f'(x) = -3x^2 + 3$. Cho $f'(x) = 0$ tìm nghiệm trong khoảng $(0; 2)$.",
          hint2: "Nghiệm là $x = 1 \\in (0; 2)$. Tính giá trị tại $x = 0, x = 1, x = 2$ rồi chọn số lớn nhất.",
          explain: "Ta có $f'(x) = -3x^2 + 3 = 0 \\Leftrightarrow x = 1$ (do $x \\in (0; 2)$). Ta tính $f(0) = 2$, $f(1) = 4$, $f(2) = -8 + 6 + 2 = 0$. Giá trị lớn nhất là $\\max_{[0; 2]} f(x) = 4$."
        },
        {
          id: 2,
          title: "Tọa độ tâm đối xứng đồ thị",
          question: "Cho hàm số $y = \\frac{2x - 3}{x + 1}$. Giao điểm của hai đường tiệm cận của đồ thị hàm số là điểm $I(x_0; y_0)$. Tính tổng $S = x_0 + y_0$.",
          correctAnswer: "1",
          acceptedAnswers: ["1", "1.0", "1,0"],
          hint1: "Đường tiệm cận đứng là $x = -1$, đường tiệm cận ngang là $y = 2$.",
          hint2: "Tọa độ giao điểm $I$ chính là $(-1; 2)$. Tính $x_0 + y_0 = -1 + 2$.",
          explain: "Đồ thị có tiệm cận đứng $x = -1$ và tiệm cận ngang $y = 2$. Giao điểm của hai đường tiệm cận là $I(-1; 2)$. Khi đó $S = x_0 + y_0 = -1 + 2 = 1$."
        },
        {
          id: 3,
          title: "Bài toán thực tế tối ưu chiều dài hàng rào",
          question: "Một bác nông dân muốn rào một khu vườn hình chữ nhật có diện tích $800\\text{ m}^2$ sát một bờ sông thẳng (bờ sông không cần rào, chỉ rào 3 cạnh còn lại). Chiều dài hàng rào ngắn nhất mà bác nông dân cần làm bằng bao nhiêu mét?",
          unit: "mét",
          correctAnswer: "80",
          acceptedAnswers: ["80", "80.0", "80,0"],
          hint1: "Gọi chiều rộng 2 cạnh vuông góc với sông là $x$ ($x > 0$). Cạnh đối diện bờ sông là $y = \\frac{800}{x}$.",
          hint2: "Chiều dài hàng rào là $L(x) = 2x + \\frac{800}{x}$. Áp dụng BĐT Cô-si hoặc lấy đạo hàm $L'(x) = 2 - \\frac{800}{x^2} = 0$.",
          explain: "Tổng chiều dài hàng rào là $L(x) = 2x + \\frac{800}{x}$. Đạo hàm $L'(x) = 2 - \\frac{800}{x^2} = 0 \\Leftrightarrow x^2 = 400 \\Leftrightarrow x = 20\\text{ m}$. Khi đó chiều dài hàng rào ngắn nhất là $L(20) = 2(20) + \\frac{800}{20} = 40 + 40 = 80\\text{ m}$."
        },
        {
          id: 4,
          title: "Đường tiệm cận xiên đi qua điểm",
          question: "Cho hàm số $y = \\frac{x^2 - 3x + 6}{x - 1}$. Đường tiệm cận xiên của đồ thị đi qua điểm $M(5; y_0)$. Tìm giá trị của $y_0$.",
          correctAnswer: "3",
          acceptedAnswers: ["3", "3.0", "3,0"],
          hint1: "Chia tử cho mẫu để tìm phương trình đường tiệm cận xiên $y = ax + b$.",
          hint2: "Ta có $x^2 - 3x + 6 = (x - 1)(x - 2) + 4 \\implies y = x - 2 + \\frac{4}{x - 1}$. Thay $x = 5$ vào $y = x - 2$.",
          explain: "Thực hiện phép chia: $y = x - 2 + \\frac{4}{x - 1}$. Tiệm cận xiên là $y = x - 2$. Điểm $M(5; y_0)$ thuộc tiệm cận xiên nên $y_0 = 5 - 2 = 3$."
        }
      ]
    },

    // -------------------------------------------------------------
    // KHỐI 12 - CHƯƠNG II: VECTƠ VÀ HỆ TRỤC TOẠ ĐỘ TRONG KHÔNG GIAN
    // -------------------------------------------------------------
    "12_2": {
      id: "12_2",
      grade: "Lớp 12",
      chapterNumber: 2,
      title: "Chương II: Vectơ và hệ trục toạ độ trong không gian",
      shortTitle: "Ôn tập Chương II: Vectơ Oxyz",
      branches: [
        {
          title: "Nhánh 1: Vectơ trong không gian",
          core: "Quy tắc 3 điểm: $\\vec{AB} + \\vec{BC} = \\vec{AC}$. Quy tắc hình hộp: $\\vec{AC}' = \\vec{AB} + \\vec{AD} + \\vec{AA}'$. Tích vô hướng: $\\vec{u} \\cdot \\vec{v} = |\\vec{u}||\\vec{v}|\\cos(\\vec{u}, \\vec{v})$.",
          formula: "$$\\vec{u} \\perp \\vec{v} \\Leftrightarrow \\vec{u} \\cdot \\vec{v} = 0; \\quad |\\vec{u}| = \\sqrt{\\vec{u}^2}$$",
          pitfall: "Cộng hai vectơ không bằng cộng hai độ lớn: $|\\vec{a} + \\vec{b}| \\le |\\vec{a}| + |\\vec{b}|$.",
          casio: "Casio 580VNX: [MENU] [5] (Vector) gán vectơ VctA, VctB tính tích vô hướng DotP."
        },
        {
          title: "Nhánh 2: Hệ trục toạ độ Oxyz",
          core: "Hệ gồm 3 trục vuông góc từng đôi một: $Ox, Oy, Oz$. Toạ độ điểm $M(x; y; z) \\Leftrightarrow \\vec{OM} = x\\vec{i} + y\\vec{j} + z\\vec{k}$. Trung điểm: $I = \\frac{A + B}{2}$. Trọng tâm: $G = \\frac{A + B + C}{3}$.",
          formula: "$$\\vec{AB} = (x_B - x_A; y_B - y_A; z_B - z_A); \\quad AB = \\sqrt{(x_B - x_A)^2 + (y_B - y_A)^2 + (z_B - z_A)^2}$$",
          pitfall: "Tính tọa độ vectơ $\\vec{AB}$ luôn lấy tọa độ ngọn trừ gốc (B trừ A).",
          casio: "Bấm [MENU] [5], gán tọa độ điểm tính khoảng cách Abs(VctA - VctB)."
        },
        {
          title: "Nhánh 3: Biểu thức toạ độ các phép toán",
          core: "Cho $\\vec{u} = (x_1; y_1; z_1)$, $\\vec{v} = (x_2; y_2; z_2)$. Tổng: $\\vec{u} + \\vec{v} = (x_1+x_2; y_1+y_2; z_1+z_2)$. Tích vô hướng: $\\vec{u} \\cdot \\vec{v} = x_1x_2 + y_1y_2 + z_1z_2$.",
          formula: "$$\\cos(\\vec{u}, \\vec{v}) = \\frac{x_1x_2 + y_1y_2 + z_1z_2}{\\sqrt{x_1^2+y_1^2+z_1^2}\\sqrt{x_2^2+y_2^2+z_2^2}}$$",
          pitfall: "Điều kiện vuông góc: $x_1x_2 + y_1y_2 + z_1z_2 = 0$.",
          casio: "Menu Vector: [OPTN] chọn Angle tính góc giữa 2 vectơ."
        }
      ],
      theorySummary: `
        <p>• <strong>Quy tắc hình hộp:</strong> Cho hình hộp $ABCD.A'B'C'D'$, ta luôn có $\\vec{AC}' = \\vec{AB} + \\vec{AD} + \\vec{AA}'$.</p>
        <p>• <strong>Toạ độ vectơ:</strong> Độ dài $|\\vec{u}| = \\sqrt{x^2 + y^2 + z^2}$. Hai vectơ cùng phương: $\\vec{u} = k\\vec{v}$.</p>
        <p>• <strong>Tích vô hướng:</strong> $\\vec{u} \\cdot \\vec{v} = x_1x_2 + y_1y_2 + z_1z_2$. Hai vectơ vuông góc khi và chỉ khi tích vô hướng bằng 0.</p>
      `,
      pitfallsSummary: `
        <li>Nhầm lẫn giữa quy tắc hình bình hành phẳng và quy tắc hình hộp không gian.</li>
        <li>Quên bình phương từng thành phần tọa độ khi tính độ dài vectơ.</li>
      `,
      mcqs: [
        {
          question: "Trong không gian $Oxyz$, cho $\\vec{a} = (2; -1; 3)$ và $\\vec{b} = (1; 0; -2)$. Vectơ $\\vec{u} = 2\\vec{a} - \\vec{b}$ có tọa độ là:",
          options: ["A. $(3; -2; 8)$", "B. $(3; -2; 4)$", "C. $(5; -2; 8)$", "D. $(1; -1; 5)$"],
          correct: "A",
          hint1: "Nhân 2 vào tọa độ của $\\vec{a}$: $2\\vec{a} = (4; -2; 6)$, sau đó trừ tọa độ của $\\vec{b}$.",
          hint2: "Hoành độ: $2(2) - 1 = 3$; Tung độ: $2(-1) - 0 = -2$; Cao độ: $2(3) - (-2) = 8$.",
          explain: "Ta có $2\\vec{a} = (4; -2; 6)$. Do đó $\\vec{u} = 2\\vec{a} - \\vec{b} = (4 - 1; -2 - 0; 6 - (-2)) = (3; -2; 8)$. Đáp án đúng là A."
        },
        {
          question: "Độ dài của vectơ $\\vec{u} = (2; -3; 6)$ bằng:",
          options: ["A. $7$", "B. $49$", "C. $\\sqrt{47}$", "D. $5$"],
          correct: "A",
          hint1: "Áp dụng công thức $|\\vec{u}| = \\sqrt{x^2 + y^2 + z^2}$.",
          hint2: "Tính $\\sqrt{2^2 + (-3)^2 + 6^2} = \\sqrt{4 + 9 + 36} = \\sqrt{49}$.",
          explain: "Độ dài $|\\vec{u}| = \\sqrt{2^2 + (-3)^2 + 6^2} = \\sqrt{4 + 9 + 36} = \\sqrt{49} = 7$. Đáp án đúng là A."
        },
        {
          question: "Cho hai điểm $A(1; 2; -1)$ và $B(3; 0; 1)$. Trung điểm $I$ của đoạn thẳng $AB$ có toạ độ là:",
          options: ["A. $(2; 1; 0)$", "B. $(4; 2; 0)$", "C. $(1; -1; 1)$", "D. $(2; 2; 0)$"],
          correct: "A",
          hint1: "Áp dụng công thức toạ độ trung điểm: $x_I = \\frac{x_A + x_B}{2}, y_I = \\frac{y_A + y_B}{2}, z_I = \\frac{z_A + z_B}{2}$.",
          hint2: "$x_I = (1+3)/2 = 2; y_I = (2+0)/2 = 1; z_I = (-1+1)/2 = 0$.",
          explain: "Toạ độ trung điểm $I$ là $\\left(\\frac{1+3}{2}; \\frac{2+0}{2}; \\frac{-1+1}{2}\\right) = (2; 1; 0)$. Đáp án đúng là A."
        },
        {
          question: "Cho hai vectơ $\\vec{u} = (1; m; 2)$ và $\\vec{v} = (2; 1; -1)$. Giá trị của $m$ để $\\vec{u} \\perp \\vec{v}$ là:",
          options: ["A. $m = 0$", "B. $m = 2$", "C. $m = -2$", "D. $m = 4$"],
          correct: "A",
          hint1: "Hai vectơ vuông góc khi tích vô hướng bằng 0: $\\vec{u} \\cdot \\vec{v} = 0$.",
          hint2: "Tính $1(2) + m(1) + 2(-1) = 0 \\Leftrightarrow 2 + m - 2 = 0$.",
          explain: "Ta có $\\vec{u} \\perp \\vec{v} \\Leftrightarrow \\vec{u} \\cdot \\vec{v} = 0 \\Leftrightarrow 1(2) + m(1) + 2(-1) = 0 \\Leftrightarrow m = 0$. Đáp án đúng là A."
        },
        {
          question: "Trong không gian $Oxyz$, góc giữa hai vectơ $\\vec{a} = (1; 0; 1)$ và $\\vec{b} = (0; 1; 1)$ bằng:",
          options: ["A. $60^\\circ$", "B. $45^\\circ$", "C. $90^\\circ$", "D. $120^\\circ$"],
          correct: "A",
          hint1: "Áp dụng công thức $\\cos(\\vec{a}, \\vec{b}) = \\frac{\\vec{a} \\cdot \\vec{b}}{|\\vec{a}||\\vec{b}|}$.",
          hint2: "Tích vô hướng bằng 1, độ dài mỗi vectơ là $\\sqrt{2}$. Suy ra $\\cos = 1/2$.",
          explain: "Ta có $\\cos(\\vec{a}, \\vec{b}) = \\frac{1(0) + 0(1) + 1(1)}{\\sqrt{1+0+1}\\sqrt{0+1+1}} = \\frac{1}{2} \\implies (\\vec{a}, \\vec{b}) = 60^\\circ$. Đáp án đúng là A."
        },
        {
          question: "Cho ba điểm $A(1; 0; 0), B(0; 2; 0), C(0; 0; 3)$. Trọng tâm $G$ của tam giác $ABC$ có toạ độ là:",
          options: ["A. $\\left(\\frac{1}{3}; \\frac{2}{3}; 1\\right)$", "B. $(1; 2; 3)$", "C. $\\left(\\frac{1}{2}; 1; \\frac{3}{2}\\right)$", "D. $(1; 1; 1)$"],
          correct: "A",
          hint1: "Áp dụng công thức trọng tâm: $G = \\frac{A + B + C}{3}$.",
          hint2: "Cộng từng toạ độ rồi chia cho 3.",
          explain: "Toạ độ trọng tâm $G$ là $\\left(\\frac{1+0+0}{3}; \\frac{0+2+0}{3}; \\frac{0+0+3}{3}\\right) = \\left(\\frac{1}{3}; \\frac{2}{3}; 1\\right)$. Đáp án đúng là A."
        }
      ],
      tfQuestions: [
        {
          id: 1,
          title: "Câu 1: Trong không gian $Oxyz$, cho các điểm $A(1; 1; 1), B(2; 3; -1), C(0; 2; 3)$.",
          items: [
            { key: "a", text: "Tọa độ của vectơ $\\vec{AB}$ là $(1; 2; -2)$.", correct: "true", explain: "Ta có $\\vec{AB} = (2-1; 3-1; -1-1) = (1; 2; -2)$, mệnh đề Đúng." },
            { key: "b", text: "Độ dài đoạn thẳng $AB$ bằng 3.", correct: "true", explain: "Ta có $AB = \\sqrt{1^2 + 2^2 + (-2)^2} = \\sqrt{1+4+4} = \\sqrt{9} = 3$, mệnh đề Đúng." },
            { key: "c", text: "Tích vô hướng $\\vec{AB} \\cdot \\vec{AC} = 0$.", correct: "false", explain: "$\\vec{AC} = (-1; 1; 2) \\implies \\vec{AB} \\cdot \\vec{AC} = 1(-1) + 2(1) + (-2)(2) = -1 + 2 - 4 = -3 \\neq 0$, mệnh đề Sai." },
            { key: "d", text: "Ba điểm $A, B, C$ thẳng hàng.", correct: "false", explain: "Vì $\\vec{AB} = (1; 2; -2)$ và $\\vec{AC} = (-1; 1; 2)$ không cùng phương nên 3 điểm tạo thành tam giác, mệnh đề Sai." }
          ]
        },
        {
          id: 2,
          title: "Câu 2: Cho tứ diện $ABCD$ có $A(1; 0; 0), B(0; 1; 0), C(0; 0; 1), D(1; 1; 1)$.",
          items: [
            { key: "a", text: "Điểm $O(0; 0; 0)$ là gốc tọa độ.", correct: "true", explain: "Gốc toạ độ $O$ có toạ độ $(0; 0; 0)$, mệnh đề Đúng." },
            { key: "b", text: "Tam giác $ABC$ là tam giác đều.", correct: "true", explain: "$AB = BC = CA = \\sqrt{2}$, cả 3 cạnh bằng nhau nên tam giác $ABC$ đều, mệnh đề Đúng." },
            { key: "c", text: "Trọng tâm tứ diện $ABCD$ có toạ độ là $\\left(\\frac{1}{2}; \\frac{1}{2}; \\frac{1}{2}\\right)$.", correct: "true", explain: "Toạ độ là $\\left(\\frac{1+0+0+1}{4}; \\frac{0+1+0+1}{4}; \\frac{0+0+1+1}{4}\\right) = \\left(\\frac{1}{2}; \\frac{1}{2}; \\frac{1}{2}\\right)$, mệnh đề Đúng." },
            { key: "d", text: "Độ dài đoạn thẳng $CD$ bằng 2.", correct: "false", explain: "$CD = \\sqrt{(1-0)^2 + (1-0)^2 + (1-1)^2} = \\sqrt{1+1+0} = \\sqrt{2} \\neq 2$, mệnh đề Sai." }
          ]
        },
        {
          id: 3,
          title: "Câu 3: Cho hai vectơ $\\vec{u} = (2; -1; 2)$ và $\\vec{v} = (1; 2; -2)$.",
          items: [
            { key: "a", text: "Độ dài $|\\vec{u}| = |\\vec{v}| = 3$.", correct: "true", explain: "Cả hai đều có độ dài $\\sqrt{4 + 1 + 4} = 3$, mệnh đề Đúng." },
            { key: "b", text: "Tích vô hướng $\\vec{u} \\cdot \\vec{v} = -4$.", correct: "true", explain: "$2(1) + (-1)(2) + 2(-2) = 2 - 2 - 4 = -4$, mệnh đề Đúng." },
            { key: "c", text: "Góc giữa hai vectơ $\\vec{u}$ và $\\vec{v}$ là góc nhọn.", correct: "false", explain: "Vì tích vô hướng $\\vec{u} \\cdot \\vec{v} = -4 < 0$ nên góc giữa hai vectơ là góc tù, mệnh đề Sai." },
            { key: "d", text: "Vectơ tổng $\\vec{u} + \\vec{v} = (3; 1; 0)$ có độ dài bằng $\\sqrt{10}$.", correct: "true", explain: "$\\vec{u} + \\vec{v} = (3; 1; 0) \\implies |\\vec{u} + \\vec{v}| = \\sqrt{3^2 + 1^2 + 0^2} = \\sqrt{10}$, mệnh đề Đúng." }
          ]
        },
        {
          id: 4,
          title: "Câu 4: Cho hình hộp $ABCD.A'B'C'D'$.",
          items: [
            { key: "a", text: "$\\vec{AB} + \\vec{AD} = \\vec{AC}$.", correct: "true", explain: "Theo quy tắc hình bình hành ở đáy $ABCD$, mệnh đề Đúng." },
            { key: "b", text: "$\\vec{AB} + \\vec{AD} + \\vec{AA}' = \\vec{AC}'$.", correct: "true", explain: "Đây là quy tắc hình hộp chuẩn SGK, mệnh đề Đúng." },
            { key: "c", text: "$\\vec{BA} + \\vec{BC} + \\vec{BB}' = \\vec{BD}'$.", correct: "true", explain: "Áp dụng quy tắc hình hộp xuất phát từ đỉnh $B$, mệnh đề Đúng." },
            { key: "d", text: "$\\vec{AC}' + \\vec{CA}' = \\vec{0}$.", correct: "true", explain: "Vì $\\vec{CA}' = -\\vec{AC}'$ nên tổng bằng vectơ không $\\vec{0}$, mệnh đề Đúng." }
          ]
        }
      ],
      saQuestions: [
        {
          id: 1,
          title: "Độ dài vectơ trong không gian",
          question: "Trong không gian $Oxyz$, cho vectơ $\\vec{u} = (2; -1; 2)$. Tính độ dài của vectơ $\\vec{u}$.",
          correctAnswer: "3",
          acceptedAnswers: ["3", "3.0", "3,0"],
          hint1: "Áp dụng công thức $|\\vec{u}| = \\sqrt{x^2 + y^2 + z^2}$.",
          hint2: "Tính $\\sqrt{2^2 + (-1)^2 + 2^2} = \\sqrt{4 + 1 + 4} = \\sqrt{9}$.",
          explain: "Ta có $|\\vec{u}| = \\sqrt{2^2 + (-1)^2 + 2^2} = \\sqrt{4 + 1 + 4} = \\sqrt{9} = 3$."
        },
        {
          id: 2,
          title: "Tích vô hướng của hai vectơ",
          question: "Cho hai vectơ $\\vec{a} = (1; 2; -3)$ và $\\vec{b} = (4; -1; 2)$. Tính tích vô hướng $\\vec{a} \\cdot \\vec{b}$.",
          correctAnswer: "-4",
          acceptedAnswers: ["-4", "-4.0", "-4,0"],
          hint1: "Áp dụng công thức tích vô hướng: $\\vec{a} \\cdot \\vec{b} = x_1x_2 + y_1y_2 + z_1z_2$.",
          hint2: "Tính $1(4) + 2(-1) + (-3)(2) = 4 - 2 - 6$.",
          explain: "Ta có $\\vec{a} \\cdot \\vec{b} = 1 \\times 4 + 2 \\times (-1) + (-3) \\times 2 = 4 - 2 - 6 = -4$."
        },
        {
          id: 3,
          title: "Tìm toạ độ thoả mãn điều kiện vuông góc",
          question: "Trong không gian $Oxyz$, cho hai vectơ $\\vec{u} = (x; 2; -1)$ và $\\vec{v} = (3; -1; 4)$. Tìm $x$ để hai vectơ $\\vec{u}$ và $\\vec{v}$ vuông góc với nhau.",
          correctAnswer: "2",
          acceptedAnswers: ["2", "2.0", "2,0"],
          hint1: "Hai vectơ vuông góc khi và chỉ khi tích vô hướng bằng 0: $\\vec{u} \\cdot \\vec{v} = 0$.",
          hint2: "Giải phương trình $3x + 2(-1) + (-1)(4) = 0 \\Leftrightarrow 3x - 6 = 0$.",
          explain: "Ta có $\\vec{u} \\perp \\vec{v} \\Leftrightarrow x(3) + 2(-1) + (-1)(4) = 0 \\Leftrightarrow 3x - 6 = 0 \\Leftrightarrow x = 2$."
        },
        {
          id: 4,
          title: "Khoảng cách giữa hai điểm trong không gian",
          question: "Cho hai điểm $A(1; 0; 2)$ và $B(3; 2; 3)$. Tính khoảng cách giữa hai điểm $A$ và $B$.",
          correctAnswer: "3",
          acceptedAnswers: ["3", "3.0", "3,0"],
          hint1: "Áp dụng công thức $AB = \\sqrt{(x_B - x_A)^2 + (y_B - y_A)^2 + (z_B - z_A)^2}$.",
          hint2: "Tính $\\sqrt{(3-1)^2 + (2-0)^2 + (3-2)^2} = \\sqrt{4 + 4 + 1}$.",
          explain: "Khoảng cách $AB = \\sqrt{(3-1)^2 + (2-0)^2 + (3-2)^2} = \\sqrt{4 + 4 + 1} = \\sqrt{9} = 3$."
        }
      ]
    }
  };

  // =========================================================================
  // BỘ MÁY SINH DỮ LIỆU ĐỘNG CHO TẤT CẢ CÁC BÀI TẬP CUỐI CHƯƠNG TOÁN 10 - 11 - 12
  // =========================================================================

  function generateDynamicChapterReview(lessonTitle, grade) {
    const lower = lessonTitle.toLowerCase();
    
    // Trích xuất số thứ tự chương (I, II, III, IV, V, VI, VII, VIII, IX hoặc 1..9)
    let chNum = 1;
    let chRoman = "I";
    if (lower.includes("chương ix") || lower.includes("chuong ix") || lower.includes("chương 9")) { chNum = 9; chRoman = "IX"; }
    else if (lower.includes("chương viii") || lower.includes("chuong viii") || lower.includes("chương 8")) { chNum = 8; chRoman = "VIII"; }
    else if (lower.includes("chương vii") || lower.includes("chuong vii") || lower.includes("chương 7")) { chNum = 7; chRoman = "VII"; }
    else if (lower.includes("chương vi") || lower.includes("chuong vi") || lower.includes("chương 6")) { chNum = 6; chRoman = "VI"; }
    else if (lower.includes("chương v") || lower.includes("chuong v") || lower.includes("chương 5")) { chNum = 5; chRoman = "V"; }
    else if (lower.includes("chương iv") || lower.includes("chuong iv") || lower.includes("chương 4")) { chNum = 4; chRoman = "IV"; }
    else if (lower.includes("chương iii") || lower.includes("chuong iii") || lower.includes("chương 3")) { chNum = 3; chRoman = "III"; }
    else if (lower.includes("chương ii") || lower.includes("chuong ii") || lower.includes("chương 2")) { chNum = 2; chRoman = "II"; }
    else { chNum = 1; chRoman = "I"; }

    const cleanTitle = lessonTitle.replace(/^bài tập cuối chương\s*[ivx0-9]*\s*:\s*/i, '').trim();
    const shortTitle = `Ôn tập Chương ${chRoman}: ${cleanTitle || 'Kiến thức cốt lõi'}`;

    // Sinh các nhánh sơ đồ tư duy tương ứng
    const branches = [
      {
        title: `Nhánh 1: Khái niệm & Định lý trọng tâm Chương ${chRoman}`,
        core: `Hệ thống hóa toàn bộ định nghĩa cơ bản, điều kiện áp dụng và các tính chất nền tảng theo chuẩn SGK ${grade} Kết nối tri thức.`,
        formula: `$$\\text{Mô hình hóa toán học cốt lõi của Chương } ${chRoman}$$`,
        pitfall: "Đọc kỹ giả thiết bài toán, phân biệt các trường hợp ngoại lai tại biên và mẫu số triệt tiêu.",
        casio: "Sử dụng các chức năng tính toán trực tiếp [MENU] để rút ngắn thời gian làm trắc nghiệm."
      },
      {
        title: `Nhánh 2: Phương pháp giải & Các dạng toán kinh điển`,
        core: "Nắm vững quy trình các bước giải: đặt ẩn, xác định tập xác định, lập phương trình/bất phương trình liên hệ và đối chiếu điều kiện.",
        formula: "$$\\text{Quy trình 4 bước: TXĐ } \\to \\text{Thiết lập } \\to \\text{Tính toán } \\to \\text{Kết luận}$$",
        pitfall: "Không đối chiếu nghiệm tìm được với điều kiện xác định ban đầu của bài toán.",
        casio: "Dùng tính năng CALC hoặc TABLE quét giá trị kiểm tra nghiệm chính xác tuyệt đối."
      },
      {
        title: `Nhánh 3: Bài toán thực tiễn & Tối ưu hóa`,
        core: "Mô hình hóa dữ liệu thực tế đời sống (chi phí, quãng đường, xác suất, hình học) thành biểu thức toán học tương ứng.",
        formula: "$$\\text{Hàm mục tiêu } f(x) \\implies \\text{Tìm } \\max/\\min \\text{ hoặc xác suất biến cố}$$",
        pitfall: "Đơn vị đo lường thực tế không đồng nhất giữa các đại lượng trong đề bài.",
        casio: "Chuyển đổi đơn vị và kiểm tra tính hợp lý của kết quả theo thực tiễn."
      }
    ];

    const theorySummary = `
      <p>• <strong>Kiến thức cốt lõi:</strong> Toàn bộ nội dung của Chương ${chRoman} (${grade} - SGK Kết nối tri thức) được liên kết chặt chẽ từ lý thuyết cơ bản đến các bài toán vận dụng thực tế.</p>
      <p>• <strong>Công thức trọng tâm:</strong> Ghi nhớ chuẩn xác các hệ thức toán học, tập xác định và quy tắc tính toán.</p>
      <p>• <strong>Kỹ năng làm bài:</strong> Kết hợp tư duy suy luận tự luận và kỹ năng bấm máy tính Casio để tối ưu hóa thời gian làm bài thi.</p>
    `;

    const pitfallsSummary = `
      <li>Không đọc kỹ yêu cầu đề bài (hỏi khẳng định đúng hay khẳng định sai).</li>
      <li>Bỏ qua điều kiện xác định cơ sở của biến số hoặc tham số.</li>
      <li>Tính toán nhầm dấu trong các phép biến đổi trung gian.</li>
    `;

    // 6 MCQs chuẩn chương
    const mcqs = [
      {
        question: `Câu 1 (Nhận biết - Chương ${chRoman}): Khẳng định nào sau đây là ĐÚNG về kiến thức trọng tâm của chương?`,
        options: [
          "A. Mọi công thức toán học đều phải thỏa mãn điều kiện xác định cơ sở.",
          "B. Điều kiện xác định không ảnh hưởng đến nghiệm của phương trình.",
          "C. Có thể bỏ qua tập xác định khi giải bài toán tối ưu thực tế.",
          "D. Nghiệm ngoại lai luôn được chấp nhận trong bài toán thực tế."
        ],
        correct: "A",
        hint1: "Xem lại điều kiện tiên quyết trong SGK Kết nối tri thức.",
        hint2: "Tập xác định là nền tảng của mọi suy luận toán học.",
        explain: "Trong toán học, mọi công thức và phép biến đổi đều phải bảo đảm điều kiện xác định cơ sở của các biểu thức. Đáp án đúng là A."
      },
      {
        question: `Câu 2 (Thông hiểu - Chương ${chRoman}): Khi giải một bài toán thực tiễn bằng mô hình toán học, bước đầu tiên quan trọng nhất là:`,
        options: [
          "A. Xác định các đại lượng, chọn ẩn số và tìm điều kiện thích hợp cho ẩn.",
          "B. Bấm máy tính ngay lập tức mà không cần đặt ẩn.",
          "C. Chọn ngẫu nhiên một công thức bất kỳ rồi thay số.",
          "D. Bỏ qua các đơn vị đo lường trong bài toán."
        ],
        correct: "A",
        hint1: "Bước khởi đầu của quy trình mô hình hóa toán học chuẩn SGK.",
        hint2: "Xác định rõ ràng đại lượng và điều kiện của ẩn là bước then chốt.",
        explain: "Quy trình mô hình hóa toán học bắt đầu bằng việc phân tích bài toán thực tế, chọn biến số thích hợp và tìm điều kiện của biến. Đáp án đúng là A."
      },
      {
        question: `Câu 3 (Vận dụng - Chương ${chRoman}): Cho hàm số $f(x)$ liên tục. Giá trị của biểu thức $P = f(x_0)$ đạt cực trị khi:`,
        options: [
          "A. Đạo hàm $f'(x)$ đổi dấu khi biến số $x$ đi qua $x_0$.",
          "B. Đạo hàm $f'(x_0) = 0$ nhưng không đổi dấu qua $x_0$.",
          "C. Hàm số luôn đồng biến trên toàn tập xác định.",
          "D. Đạo hàm cấp một luôn mang giá trị dương."
        ],
        correct: "A",
        hint1: "Điều kiện đủ để hàm số đạt cực trị tại một điểm.",
        hint2: "Đạo hàm bắt buộc phải đổi dấu từ dương sang âm (cực đại) hoặc từ âm sang dương (cực tiểu).",
        explain: "Điều kiện đủ để hàm số có cực trị tại $x_0$ là đạo hàm đổi dấu khi đi qua $x_0$. Đáp án đúng là A."
      },
      {
        question: `Câu 4 (Thông hiểu): Khi sử dụng máy tính cầm tay (Casio) để hỗ trợ giải toán trắc nghiệm, thao tác nào giúp kiểm tra nghiệm chính xác nhất?`,
        options: [
          "A. Sử dụng chức năng CALC gán giá trị nghiệm vào biểu thức.",
          "B. Tắt máy tính và ước lượng bằng mắt.",
          "C. Chỉ nhìn vào số đầu tiên của đáp án.",
          "D. Đổi đơn vị sang độ khi đề bài yêu cầu radian."
        ],
        correct: "A",
        hint1: "Chức năng CALC kiểm tra giá trị biểu thức tại từng phương án.",
        hint2: "Nhập vế trái trừ vế phải rồi bấm CALC gán nghiệm.",
        explain: "Lệnh CALC gán giá trị của $x$ vào biểu thức $f(x)$ giúp kiểm tra nhanh xem giá trị có bằng 0 hay không. Đáp án đúng là A."
      },
      {
        question: `Câu 5 (Vận dụng): Cho biểu thức $A = 2x + \\frac{8}{x}$ với $x > 0$. Giá trị nhỏ nhất của $A$ bằng:`,
        options: ["A. $8$", "B. $4$", "C. $10$", "D. $6$"],
        correct: "A",
        hint1: "Áp dụng bất đẳng thức Cô-si cho hai số dương $2x$ và $\\frac{8}{x}$.",
        hint2: "Ta có $2x + \\frac{8}{x} \\ge 2\\sqrt{2x \\cdot \\frac{8}{x}} = 2\\sqrt{16} = 8$.",
        explain: "Áp dụng BĐT Cô-si: $A = 2x + \\frac{8}{x} \\ge 2\\sqrt{2x \\cdot \\frac{8}{x}} = 2\\sqrt{16} = 8$. Dấu bằng xảy ra khi $2x = \\frac{8}{x} \\Leftrightarrow x = 2$. Đáp án đúng là A."
      },
      {
        question: `Câu 6 (Vận dụng cao): Một hình chữ nhật có chu vi bằng $40\\text{ m}$. Diện tích lớn nhất của hình chữ nhật đó bằng bao nhiêu?`,
        options: ["A. $100\\text{ m}^2$", "B. $80\\text{ m}^2$", "C. $120\\text{ m}^2$", "D. $90\\text{ m}^2$"],
        correct: "A",
        hint1: "Nửa chu vi là $x + y = 20$. Diện tích là $S = x(20 - x)$.",
        hint2: "Hình chữ nhật có chu vi cố định đạt diện tích lớn nhất khi nó là hình vuông.",
        explain: "Nửa chu vi là $20\\text{ m}$. Diện tích $S(x) = x(20 - x) = -x^2 + 20x = -(x - 10)^2 + 100 \\le 100\\text{ m}^2$. Dấu bằng xảy ra khi $x = y = 10\\text{ m}$. Đáp án đúng là A."
      }
    ];

    // 4 TF questions (16 items)
    const tfQuestions = [
      {
        id: 1,
        title: `Câu 1: Xét các mệnh đề toán học nền tảng của Chương ${chRoman}:`,
        items: [
          { key: "a", text: "Mọi biểu thức toán học đều phải được xác định trên tập số thực trước khi tính toán.", correct: "true", explain: "Đây là nguyên tắc tiên quyết trong giải toán, mệnh đề Đúng." },
          { key: "b", text: "Khi giải bất phương trình, nhân hoặc chia hai vế với số âm thì phải đổi chiều.", correct: "true", explain: "Quy tắc đổi chiều khi nhân chia số âm là chuẩn đại số, mệnh đề Đúng." },
          { key: "c", text: "Giá trị cực đại của hàm số luôn luôn lớn hơn mọi giá trị cực tiểu của nó.", correct: "false", explain: "Cực trị chỉ mang tính địa phương trong một khoảng lân cận, mệnh đề Sai." },
          { key: "d", text: "Hai đại lượng tỉ lệ thuận luôn có tỉ số giữa chúng là hằng số không đổi.", correct: "true", explain: "Định nghĩa chuẩn của tỉ lệ thuận: $y/x = k$, mệnh đề Đúng." }
        ]
      },
      {
        id: 2,
        title: `Câu 2: Cho hàm số $f(x) = x^3 - 3x + 1$ trên đoạn $[0; 2]$.`,
        items: [
          { key: "a", text: "Tập xác định của hàm số là $D = \\mathbb{R}$.", correct: "true", explain: "Hàm đa thức xác định trên toàn $\\mathbb{R}$, mệnh đề Đúng." },
          { key: "b", text: "Đạo hàm của hàm số là $f'(x) = 3x^2 - 3$.", correct: "true", explain: "Đạo hàm chuẩn: $(x^3 - 3x + 1)' = 3x^2 - 3$, mệnh đề Đúng." },
          { key: "c", text: "Hàm số đồng biến trên toàn bộ đoạn $[0; 2]$.", correct: "false", explain: "Trên $(0; 1)$, $f'(x) < 0$ nên hàm nghịch biến trên $[0; 1]$, mệnh đề Sai." },
          { key: "d", text: "Giá trị nhỏ nhất của hàm số trên đoạn $[0; 2]$ bằng $-1$.", correct: "true", explain: "Ta có $f(0) = 1, f(1) = -1, f(2) = 3$. Giá trị nhỏ nhất là $f(1) = -1$, mệnh đề Đúng." }
        ]
      },
      {
        id: 3,
        title: `Câu 3: Một hình chữ nhật có chu vi bằng $24\\text{ cm}$. Gọi $x$ (cm) là chiều rộng của hình chữ nhật ($0 < x < 12$).`,
        items: [
          { key: "a", text: "Chiều dài của hình chữ nhật là $12 - x$ (cm).", correct: "true", explain: "Nửa chu vi là $24 / 2 = 12\\text{ cm}$, mệnh đề Đúng." },
          { key: "b", text: "Diện tích hình chữ nhật là $S(x) = x(12 - x) = -x^2 + 12x$.", correct: "true", explain: "Diện tích bằng dài nhân rộng, mệnh đề Đúng." },
          { key: "c", text: "Diện tích hình chữ nhật lớn nhất khi $x = 6\\text{ cm}$.", correct: "true", explain: "Hàm bậc 2 có đỉnh tại $x = -b/(2a) = -12/(-2) = 6\\text{ cm}$, mệnh đề Đúng." },
          { key: "d", text: "Diện tích lớn nhất đạt được là $40\\text{ cm}^2$.", correct: "false", explain: "Diện tích lớn nhất là $S(6) = 6(12 - 6) = 36\\text{ cm}^2 \\neq 40$, mệnh đề Sai." }
        ]
      },
      {
        id: 4,
        title: `Câu 4: Xét bài toán tối ưu và mô hình hóa trong thực tiễn:`,
        items: [
          { key: "a", text: "Hàm chi phí $C(x)$ tăng khi số lượng sản phẩm $x$ tăng.", correct: "true", explain: "Sản xuất càng nhiều sản phẩm thì tổng chi phí càng tăng, mệnh đề Đúng." },
          { key: "b", text: "Chi phí trung bình trên mỗi sản phẩm là $\\bar{C}(x) = \\frac{C(x)}{x}$.", correct: "true", explain: "Định nghĩa chuẩn chi phí trung bình, mệnh đề Đúng." },
          { key: "c", text: "Lợi nhuận bằng doanh thu trừ đi chi phí: $P(x) = R(x) - C(x)$.", correct: "true", explain: "Công thức kinh tế cơ bản, mệnh đề Đúng." },
          { key: "d", text: "Doanh thu luôn luôn lớn hơn chi phí trong mọi trường hợp.", correct: "false", explain: "Khi mới bắt đầu sản xuất hoặc sản lượng quá thấp thì doanh nghiệp có thể bị lỗ, mệnh đề Sai." }
        ]
      }
    ];

    // 4 Short Answer questions
    const saQuestions = [
      {
        id: 1,
        title: `Tìm giá trị cực trị của biểu thức`,
        question: `Tìm giá trị nhỏ nhất của biểu thức $P = x^2 - 4x + 9$ với $x \\in \\mathbb{R}$.`,
        correctAnswer: "5",
        acceptedAnswers: ["5", "5.0", "5,0"],
        hint1: "Biến đổi biểu thức thành dạng bình phương cộng hằng số: $P = (x - a)^2 + b$.",
        hint2: "$P = (x - 2)^2 + 5$. Vì $(x - 2)^2 \\ge 0$ nên $P \\ge 5$.",
        explain: "Ta có $P = x^2 - 4x + 4 + 5 = (x - 2)^2 + 5$. Do $(x - 2)^2 \\ge 0, \\forall x$ nên giá trị nhỏ nhất của $P$ là $5$ khi $x = 2$."
      },
      {
        id: 2,
        title: `Bài toán tìm số lượng tối ưu`,
        question: `Một xưởng may sản xuất $x$ chiếc áo với lợi nhuận $P(x) = -x^2 + 80x - 700$ (nghìn đồng). Để đạt lợi nhuận lớn nhất, xưởng cần sản xuất bao nhiêu chiếc áo?`,
        unit: "chiếc áo",
        correctAnswer: "40",
        acceptedAnswers: ["40", "40.0", "40,0"],
        hint1: "Hàm lợi nhuận là hàm bậc hai có $a = -1 < 0$. Điểm cực đại đạt tại hoành độ đỉnh parabol.",
        hint2: "Hoành độ đỉnh $x = -\\frac{b}{2a} = -\\frac{80}{2(-1)} = 40$.",
        explain: "Hàm lợi nhuận $P(x) = -x^2 + 80x - 700$ đạt giá trị lớn nhất tại $x = -\\frac{80}{2(-1)} = 40$. Vậy xưởng cần sản xuất 40 chiếc áo."
      },
      {
        id: 3,
        title: `Tính toán độ dài và khoảng cách`,
        question: `Cho tam giác vuông có hai cạnh góc vuông lần lượt là $6\\text{ cm}$ và $8\\text{ cm}$. Tính độ dài cạnh huyền của tam giác đó theo centimet.`,
        unit: "cm",
        correctAnswer: "10",
        acceptedAnswers: ["10", "10.0", "10,0"],
        hint1: "Áp dụng định lý Py-ta-go: $c = \\sqrt{a^2 + b^2}$.",
        hint2: "Tính $\\sqrt{6^2 + 8^2} = \\sqrt{36 + 64} = \\sqrt{100}$.",
        explain: "Theo định lý Py-ta-go, độ dài cạnh huyền là $c = \\sqrt{6^2 + 8^2} = \\sqrt{36 + 64} = \\sqrt{100} = 10\\text{ cm}$."
      },
      {
        id: 4,
        title: `Tính diện tích hình chữ nhật`,
        question: `Một mảnh vườn hình chữ nhật có chu vi bằng $60\\text{ m}$ và diện tích lớn nhất có thể. Tính diện tích lớn nhất đó theo mét vuông.`,
        unit: "m²",
        correctAnswer: "225",
        acceptedAnswers: ["225", "225.0", "225,0"],
        hint1: "Nửa chu vi là $30\\text{ m}$. Cạnh của hình vuông có chu vi này là $30 / 2 = 15\\text{ m}$.",
        hint2: "Diện tích lớn nhất đạt được khi hình chữ nhật là hình vuông: $S = 15^2$.",
        explain: "Nửa chu vi là $60 / 2 = 30\\text{ m}$. Hình chữ nhật có chu vi cố định đạt diện tích lớn nhất khi là hình vuông cạnh $15\\text{ m}$. Diện tích lớn nhất là $15 \\times 15 = 225\\text{ m}^2$."
      }
    ];

    return {
      id: `${grade}_${chNum}`,
      grade: grade,
      chapterNumber: chNum,
      title: lessonTitle,
      shortTitle: shortTitle,
      branches: branches,
      theorySummary: theorySummary,
      pitfallsSummary: pitfallsSummary,
      mcqs: mcqs,
      tfQuestions: tfQuestions,
      saQuestions: saQuestions
    };
  }

  // =========================================================================
  // HÀM CHÍNH: XÂY DỰNG BÀI HỌC ÔN TẬP CUỐI CHƯƠNG (BUILD CHAPTER REVIEW LESSON)
  // =========================================================================

  function buildKNTTChapterReviewLesson(lessonTitle, gradeOrClass) {
    const grade = (typeof window.getGradeFromClassName === 'function') 
      ? window.getGradeFromClassName(gradeOrClass) 
      : (gradeOrClass || 'Lớp 12');

    const lower = (lessonTitle || '').toLowerCase();
    
    // Tìm trong ngân hàng dữ liệu chuyên biệt trước
    let chapterData = null;
    if (grade === "Lớp 12") {
      if (lower.includes("chương i:") || lower.includes("chương 1") || lower.includes("đạo hàm") || lower.includes("khảo sát")) {
        chapterData = CHAPTER_REVIEWS_DB["12_1"];
      } else if (lower.includes("chương ii:") || lower.includes("chương 2") || lower.includes("vectơ") || lower.includes("toạ độ trong không gian")) {
        chapterData = CHAPTER_REVIEWS_DB["12_2"];
      }
    }

    // Nếu chưa có trong DB cố định, tự động sinh chuẩn theo SGK Kết nối tri thức
    if (!chapterData) {
      chapterData = generateDynamicChapterReview(lessonTitle, grade);
    }

    const studentName = (window.studentInfo && window.studentInfo.name) ? window.studentInfo.name : 'Minh Anh';
    const mindMapHTML = createChapterMindMapHTML(chapterData, studentName);

    // Xáo trộn ngẫu nhiên đáp án A, B, C, D của 6 câu trắc nghiệm
    const clonedMCQs = JSON.parse(JSON.stringify(chapterData.mcqs));
    if (typeof window.randomizeSingleMCQ === 'function') {
      const letters = ['A', 'B', 'C', 'D'];
      clonedMCQs.forEach(mcq => {
        const randTarget = letters[Math.floor(Math.random() * letters.length)];
        window.randomizeSingleMCQ(mcq, randTarget);
      });
    }

    // Trả về cấu trúc bài học hoàn chỉnh tương thích 100% với Web App
    return {
      key: `chapter_review_${grade}_${chapterData.chapterNumber}`,
      isChapterReview: true,
      lessonTitle: lessonTitle,
      class: grade,
      chapterShortTitle: chapterData.shortTitle,
      chapterNumber: chapterData.chapterNumber,
      branches: chapterData.branches,
      sections: [
        {
          sectionNumber: 1,
          sectionTitle: `Sơ đồ tư duy & Tóm tắt kiến thức ${chapterData.shortTitle}`,
          theory: mindMapHTML,
          mcqs: clonedMCQs,
          mcqPool: clonedMCQs
        }
      ],
      tfQuestions: JSON.parse(JSON.stringify(chapterData.tfQuestions)),
      saQuestions: JSON.parse(JSON.stringify(chapterData.saQuestions))
    };
  }

  // Xuất ra phạm vi toàn cục window
  window.buildKNTTChapterReviewLesson = buildKNTTChapterReviewLesson;
  window.createChapterMindMapHTML = createChapterMindMapHTML;
  window.CHAPTER_REVIEWS_DB = CHAPTER_REVIEWS_DB;

})();
